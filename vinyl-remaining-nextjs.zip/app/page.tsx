'use client';
import VinylRemainingApp from "@/components/VinylRemainingApp";

export default function Page() {
  return <VinylRemainingApp />;
}
